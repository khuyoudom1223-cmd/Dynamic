const { KHQRResponse } = require("../model");
const { errorCode, emv } = require("../constant");
const axios = require("axios");

async function isAccountIDExist(url, accountID) {
    // Check account ID length
    if (accountID.length > emv.INVALID_LENGTH.BAKONG_ACCOUNT)
        throw KHQRResponse(null, errorCode.BAKONG_ACCOUNT_ID_LENGTH_INVALID);
        
    if (accountID.split("@").length != 2)
        throw KHQRResponse(null, errorCode.BAKONG_ACCOUNT_ID_INVALID);

    // fetch from URL
    try {
        let response = await axios.post(
            url,
            { accountId: accountID },
            {
                header: {
                    "Content-Type": "application/json",
                },
                timeout: 45 * 1000,
            }
        );

        const respData = response.data;

        // Getting Response
        const responseCode = respData.responseCode;
        const error = respData.errorCode;

        if (error == 11) return { bakongAccountExisted: false };
        if (error == 12)
            throw KHQRResponse(null, errorCode.BAKONG_ACCOUNT_ID_INVALID);

        // Return value
        if (responseCode == 0) return { bakongAccountExisted: true };
        else return { bakongAccountExisted: false };
    } catch (error) {
        if (error.code === 'ECONNABORTED')
            throw KHQRResponse(null, errorCode.CONNECTION_TIMEOUT);
        throw KHQRResponse(null, errorCode.CONNECTION_TIMEOUT);
    }
}

module.exports = isAccountIDExist;
