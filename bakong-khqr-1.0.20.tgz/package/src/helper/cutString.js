module.exports = function cutString(string) {
    const sliceIndex = 2;

    // Get first 2
    const tag = string.slice(0, sliceIndex);
    const length = parseInt(string.slice(sliceIndex, sliceIndex * 2));
    const value = string.slice(sliceIndex * 2, sliceIndex * 2 + length);
    const slicedString = string.slice(sliceIndex * 2 + length);

    return {
        tag: tag,
        value: value,
        slicedString: slicedString,
    };
};
