const axios = require("axios");
const { errorCode } = require("../constant");
const { KHQRResponse } = require("../model");

class SourceInfo {
    constructor(appIconUrl, appName, appDeepLinkCallback) {
        this.appIconUrl = appIconUrl || null;
        this.appName = appName || null;
        this.appDeepLinkCallback = appDeepLinkCallback || null;
    }
}

function isValidLink(link) {
    try {
        let url = new URL(link);

        if (url.pathname != "/v1/generate_deeplink_by_qr") return false;
    } catch (error) {
        return false;
    }
    return true;
}

async function callDeepLinkAPI(url, data) {
    try {
        let response = await axios.post(url, data, {
            headers: {
                "Content-Type": "application/json",
            },
            timeout: 45 * 1000,
        });

        const respBody = response.data;

        // Getting Response
        const error = respBody.errorCode;

        if (response == undefined)
            throw KHQRResponse(null, errorCode.CONNECTION_TIMEOUT);

        if (error == 5)
            return KHQRResponse(null, errorCode.INVALID_DEEP_LINK_SOURCE_INFO);
        else if (error == 4)
            return KHQRResponse(null, errorCode.INTERNAL_SERVER_ERROR);
        return respBody;
    } catch (error) {
        if (error.code === 'ECONNABORTED')
            throw KHQRResponse(null, errorCode.CONNECTION_TIMEOUT);
        throw KHQRResponse(null, errorCode.CONNECTION_TIMEOUT);
    }
}

module.exports = { isValidLink, callDeepLinkAPI, SourceInfo };
