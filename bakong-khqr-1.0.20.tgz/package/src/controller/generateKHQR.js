const { emv, khqrData, errorCode } = require("../constant");
const crc16 = require("../helper/crc16");
const {
    PointOfInitiationMethod,
    PayloadFormatIndicator,
    GlobalUnqiueIdentifier,
    TransactionCurrency,
    CountryCode,
    MerchantCity,
    MerchantCategoryCode,
    TransactionAmount,
    MerchantName,
    TimeStamp,
    MerchantInformationLanguageTemplate,
    AdditionalData,
    UnionpayMerchantAccount,
} = require("../MerchantCode");
const { KHQRResponse } = require("../model");

/**
 * Generate KHQR helper Function
 * 1. create object of subtags elements
 * 2. create the string by passing tag and value to the instances
 * 3. calculate CRC
 * 4. return the value
 * @param {object} information 
 * @param {string} type 
 * @returns string of KHQR
 */
function generateKHQR(information, type) {
    // Getting information from information instance
    // If the merchant QR, there will be the merchantID and acquiring bank
    let merchantInfo = {
        bakongAccountID: information.bakongAccountID,
        isMerchant: false
    };

    if (type == "merchant")
        merchantInfo = {
            bakongAccountID: information.bakongAccountID,
            merchantID: information.merchantID,
            acquiringBank: information.acquiringBank,
            isMerchant: true
        };
    else
        merchantInfo = {
            bakongAccountID: information.bakongAccountID,
            accountInformation: information.accountInformation,
            acquiringBank: information.acquiringBank,
            isMerchant: false,
        };

    const additionalDataInformation = {
        billNumber: information.billNumber,
        mobileNumber: information.mobileNumber,
        storeLabel: information.storeLabel,
        terminalLabel: information.terminalLabel,
        purposeOfTransaction: information.purposeOfTransaction
    };

    const languageInformation = {
        languagePreference: information.languagePreference,
        merchantNameAlternateLanguage: information.merchantNameAlternateLanguage,
        merchantCityAlternateLanguage: information.merchantCityAlternateLanguage
    }
    
    try {
        const amount = information.amount

        // Creating each tag
        const payloadFormatIndicator = new PayloadFormatIndicator(
            emv.PAYLOAD_FORMAT_INDICATOR,
            emv.DEFAULT_PAYLOAD_FORMAT_INDICATOR
        );

        // Static QR is when QR Code has no amount tag
        // in this case the amount is 0
        let QRType = emv.DYNAMIC_QR;

        if (amount == undefined || amount == 0) QRType = emv.STATIC_QR
        const pointOfInitiationMethod = new PointOfInitiationMethod(
            emv.POINT_OF_INITIATION_METHOD,
            QRType
        );

        let upi;
        if (information.upiMerchantAccount)
            upi = new UnionpayMerchantAccount(emv.UNIONPAY_MERCHANT_ACCOUNT, information.upiMerchantAccount)

        // Setting tag for merchant account type
        let KHQRType = emv.MERCHANT_ACCOUNT_INFORMATION_INDIVIDUAL;
        if (type == "merchant")
            KHQRType = emv.MERCHANT_ACCOUNT_INFORMATION_MERCHANT;

        const globalUniqueIdentifier = new GlobalUnqiueIdentifier(
            KHQRType,
            merchantInfo
        );

        const merchantCategoryCode = new MerchantCategoryCode(
            emv.MERCHANT_CATEGORY_CODE,
            String(information.merchantCategoryCode ?? emv.DEFAULT_MERCHANT_CATEGORY_CODE)
        );

        const currency = new TransactionCurrency(
            emv.TRANSACTION_CURRENCY,
            information.currency
        );

        if (information.currency == khqrData.currency.usd && upi) throw KHQRResponse(null, errorCode.UPI_ACCOUNT_INFORMATION_INVALID_CURRENCY);

        // Array of KHQR tags to loop and get the string of tags
        const KHQRInstances = [
            payloadFormatIndicator,
            pointOfInitiationMethod,
            upi || "",
            globalUniqueIdentifier,
            merchantCategoryCode,
            currency
        ];

        if (!(amount == undefined || amount == 0)) {
            let amountInput = information.amount;
            if (information.currency == khqrData.currency.khr) {
                if (amountInput % 1 == 0) amountInput = Math.round(amountInput)
                else throw KHQRResponse(null, errorCode.TRANSACTION_AMOUNT_INVALID);
            } else {
                const amountSplit = String(amountInput).split(".")
                const precision = amountSplit[1]
                if (precision != undefined && precision.length > 2)
                    throw KHQRResponse(null, errorCode.TRANSACTION_AMOUNT_INVALID);
                if (precision != undefined)
                    amountInput = parseFloat(amountInput).toFixed(2);
            }
            const amount = new TransactionAmount(
                emv.TRANSACTION_AMOUNT,
                amountInput
            );
            KHQRInstances.push(amount)
        }

        const countryCode = new CountryCode(
            emv.COUNTRY_CODE,
            emv.DEFAULT_COUNTRY_CODE
        );
        KHQRInstances.push(countryCode);

        const merchantName = new MerchantName(
            emv.MERCHANT_NAME,
            information.merchantName
        );
        KHQRInstances.push(merchantName);

        const merchantCity = new MerchantCity(
            emv.MERCHANT_CITY,
            String(information.merchantCity || emv.DEFAULT_MERCHANT_CITY)
        );
        KHQRInstances.push(merchantCity);

        // Additional data wont be added if there is undefined
        let additionalData;
        const isEmptyAdditionalData = Object.values(
            additionalDataInformation
        ).every((el) => el == null || el == undefined || el == "");

        if (!isEmptyAdditionalData) {
            additionalData = new AdditionalData(
                emv.ADDITIONAL_DATA_TAG,
                additionalDataInformation
            );
            KHQRInstances.push(additionalData);
        }

        const isEmptyLanguageTEmplate = Object.values(
            languageInformation
        ).every((el) => el == null || el == undefined || el == "");

        if (!isEmptyLanguageTEmplate) {
            const languageTemplate = new MerchantInformationLanguageTemplate(emv.MERCHANT_INFORMATION_LANGUAGE_TEMPLATE, languageInformation)
            KHQRInstances.push(languageTemplate);
        }


        if(QRType === emv.DYNAMIC_QR) {
            if(!information.expirationTimestamp) {
                throw KHQRResponse(null, errorCode.EXPIRATION_TIMESTAMP_REQUIRED)
            }
            const timeStamp = new TimeStamp(
                emv.TIMESTAMP_TAG,
                {
                    creationTimestamp: Date.now(),
                    expirationTimestamp: information.expirationTimestamp
                },
                QRType
            );
            KHQRInstances.push(timeStamp);
        }

        let khqrNoCrc = "";

        for (let i = 0; i < KHQRInstances.length; i++) {
            khqrNoCrc += KHQRInstances[i].toString();
        }

        let khqr = khqrNoCrc + emv.CRC + emv.CRC_LENGTH;
        khqr += crc16(khqr);

        return khqr;
    } catch (error) {
        return error;
    }
}

module.exports = generateKHQR;
