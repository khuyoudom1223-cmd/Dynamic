function isNumberic(value) {
    return /^\d+$/.test(value);
}

function isValid(tag, length, value) {
    return isNumberic(tag) && length === value.length;
}

function extractTLV(string) {
    const sliceIndex = 2;
    const tag = string.slice(0, sliceIndex);
    const length = parseInt(string.slice(sliceIndex, sliceIndex * 2));
    const value = string.slice(sliceIndex * 2, sliceIndex * 2 + length);
    const remainString = string.slice(sliceIndex * 2 + length);

    return {
        tag: tag,
        length: length,
        value: value,
        remainString: remainString,
    };
}

/**
 * Decode a non-KHQR string
 *
 * @param {String} qr - The QR code string to decode.
 * @returns {Object} The decoded object.
 */
function decodeNonKhqr(qr) {
    const firstLevelData = {};
    const finalData = {};
    let remaningQR = qr;

    // first-level
    do {
        const { tag, length, value, remainString } = extractTLV(remaningQR);
        if (!isValid(tag, length, value)) break;
        firstLevelData[tag] = value;
        remaningQR = remainString;
    } while (remaningQR);

    // second-level
    for (const tag in firstLevelData) {
        let remainingValue = firstLevelData[tag];
        finalData[tag] = remainingValue;

        const secondLevelData = {};
        const thirdLevelData = {};

        // check range 26-51, 80-99 and 64
        if (
            !(tag >= 26 && tag <= 51) &&
            !(tag >= 80 && tag <= 99) &&
            tag !== "64" &&
            tag !== "62"
        )
            continue;

        // check if value has emv format
        if (remainingValue.length >= 6) {
            do {
                const { tag: subTag, length, value: subValue, remainString } = extractTLV(remainingValue);
                if (!isValid(subTag, length, subValue)) break;
                remainingValue = remainString;

                // check for main tag is 62 and subtags range from 50-99
                if (tag === "62" && subTag >= 50 && subTag <= 99) {
                    let remainingValueL3 = subValue;

                    // third-level
                    do {
                        const { tag: subTagL3, length, value: valueL3, remainString} = extractTLV(remainingValueL3);
                        if (!isValid(subTagL3, length, valueL3)) break;
                        thirdLevelData[subTagL3] = valueL3;
                        remainingValueL3 = remainString;
                    } while (remainingValueL3);
                }

                if (Object.keys(thirdLevelData).length > 0) {
                    secondLevelData[subTag] = thirdLevelData;
                } else {
                    secondLevelData[subTag] = subValue;
                }
            } while (remainingValue);

            if (Object.keys(secondLevelData).length > 0) {
                finalData[tag] = secondLevelData;
            }
        }
    }
    return finalData;
}

module.exports = decodeNonKhqr;
