const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class TransactionAmount extends TagLengthString {
    constructor(tag, value) {
        if (
            String(value).length > emv.INVALID_LENGTH.AMOUNT ||
            String(value).includes("-") ||
            value == "" ||
            value == undefined ||
            value == null
        )
            throw KHQRResponse(null, errorCode.TRANSACTION_AMOUNT_INVALID);

        super(tag, value);
    }
}

module.exports = TransactionAmount;
