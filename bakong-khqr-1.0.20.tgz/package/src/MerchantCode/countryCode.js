const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class CountryCode extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined) 
            throw KHQRResponse(null, errorCode.COUNTRY_CODE_TAG_REQUIRED)
        else if (value.length > emv.INVALID_LENGTH.COUNTRY_CODE) 
            throw KHQRResponse(null, errorCode.COUNTRY_CODE_LENGTH_INVALID)
        super(tag, value);
    }
}

module.exports = CountryCode;
