const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class MerchantName extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined) 
            throw KHQRResponse(null, errorCode.MERCHANT_NAME_REQUIRED)
        else if (value.length > emv.INVALID_LENGTH.MERCHANT_NAME) 
            throw KHQRResponse(null, errorCode.MERCHANT_NAME_LENGTH_INVALID)
        super(tag, value);
    }
}

module.exports = MerchantName;
