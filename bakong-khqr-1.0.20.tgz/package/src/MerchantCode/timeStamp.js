const { errorCode, emv } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class TimeStamp extends TagLengthString {
    constructor(tag, timestamp, poi) {
        const creationTimestamp = Number(timestamp?.creationTimestamp);
        const expirationTimestamp = Number(timestamp?.expirationTimestamp);

        if(poi === emv.DYNAMIC_QR) {
            if(!timestamp || !expirationTimestamp) {
                throw KHQRResponse(null, errorCode.EXPIRATION_TIMESTAMP_REQUIRED);
            }
            if(expirationTimestamp.toString().length !== emv.INVALID_LENGTH.TIMESTAMP) {
                throw KHQRResponse(null, errorCode.EXPIRATION_TIMESTAMP_LENGTH_INVALID);
            }
            
            if(isNaN((new Date(expirationTimestamp)).getTime())) {
                throw KHQRResponse(null, errorCode.INVALID_DYNAMIC_KHQR);
            }

            if(expirationTimestamp < creationTimestamp) {
                throw KHQRResponse(null, errorCode.EXPIRATION_TIMESTAMP_IN_THE_PAST);
            }

            if(expirationTimestamp < Date.now()) {
                throw KHQRResponse(null, errorCode.KHQR_EXPIRED);
            }
        }

        let timestampString = "";
        const createdTimestamp = new TimeStampMiliSecond(emv.CREATION_TIMESTAMP, creationTimestamp);
        timestampString += createdTimestamp.toString();

        const expiredTimestamp = new TimeStampMiliSecond(emv.EXPIRATION_TIMESTAMP, expirationTimestamp);
        timestampString += expiredTimestamp.toString()

        super(tag, timestampString);
    }
}

class TimeStampMiliSecond extends TagLengthString {
    constructor(tag, value) {
        super(tag, value)
    }
}

module.exports = TimeStamp;
