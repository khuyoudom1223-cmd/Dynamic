const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class MerchantInformationLanguageTemplate extends TagLengthString {
    constructor(tag, value) {
        if (value == null) {
            value = {
                languagePreference: null,
                merchantNameAlternateLanguage: null,
                merchantCityAlternateLanguage: null
            }
        }

        if (value.languagePreference && !value.merchantNameAlternateLanguage)
            throw KHQRResponse(null, errorCode.MERCHANT_NAME_ALTERNATE_LANGUAGE_REQUIRED);

        let merchantInformationLanguageTemplateString = "";

        if (value.merchantNameAlternateLanguage != undefined) {
            const perference = new LanguagePreference(emv.LANGUAGE_PREFERENCE, value.languagePreference);
            merchantInformationLanguageTemplateString += perference.toString();
        }

        if (value.merchantNameAlternateLanguage != undefined) {
            const alterName = new MerchantNameAlternateLanguage(emv.MERCHANT_NAME_ALTERNATE_LANGUAGE, value.merchantNameAlternateLanguage);
            merchantInformationLanguageTemplateString += alterName.toString();
        }

        if (value.merchantCityAlternateLanguage != undefined) {
            const alterCity = new MerchantCityAlternateLanguage(emv.MERCHANT_CITY_ALTERNATE_LANGUAGE, value.merchantCityAlternateLanguage);
            merchantInformationLanguageTemplateString += alterCity.toString();
        }

        super(tag, merchantInformationLanguageTemplateString);

        this.data = value
    }
}

class LanguagePreference extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.LANGUAGE_PREFERENCE || value == "")
            throw KHQRResponse(null, errorCode.LANGUAGE_PREFERENCE_LENGTH_INVALID);
        super(tag, value);
    }
}

class MerchantNameAlternateLanguage extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.MERCHANT_NAME_ALTERNATE_LANGUAGE || value == "")
            throw KHQRResponse(null, errorCode.MERCHANT_NAME_ALTERNATE_LANGUAGE_LENGTH_INVALID);
        super(tag, value);
    }
}

class MerchantCityAlternateLanguage extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.MERCHANT_CITY_ALTERNATE_LANGUAGE || value== "")
            throw KHQRResponse(null, errorCode.MERCHANT_CITY_ALTERNATE_LANGUAGE_LENGTH_INVALID);
        super(tag, value);
    }
}

module.exports = MerchantInformationLanguageTemplate;
