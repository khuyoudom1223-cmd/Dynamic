const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class MerchantCity extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined)
            throw KHQRResponse(null, errorCode.MERCHANT_CITY_TAG_REQUIRED)
        else if (value.length > emv.INVALID_LENGTH.MERCHANT_CITY)
            throw KHQRResponse(null, errorCode.MERCHANT_CITY_LENGTH_INVALID)
        super(tag, value);
    }
}

module.exports = MerchantCity;
