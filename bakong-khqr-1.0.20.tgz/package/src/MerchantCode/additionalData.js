const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class AdditionalData extends TagLengthString {
    constructor(tag, additionalData) {
        if (additionalData == null)
            additionalData = {
                billNumberInput: null,
                mobileNumberInput: null,
                storeLabelInput: null,
                terminalLabelInput: null,
            };

        // Getting information from additionalData
        const billNumberInput = additionalData.billNumber;
        const mobileNumberInput = additionalData.mobileNumber;
        const storeLabelInput = additionalData.storeLabel;
        const terminalLabelInput = additionalData.terminalLabel;
        const purposeOfTransaction = additionalData.purposeOfTransaction;

        let billNumber;
        let mobileNumber;
        let storeLabel;
        let terminalLabel;

        // Create additional data tag by combine all three sub tags
        let additionalDataString = "";
        if (billNumberInput != undefined) {
            billNumber = new BillNumber(emv.BILLNUMBER_TAG, billNumberInput);
            additionalDataString += billNumber.toString();
        }
        if (mobileNumberInput != undefined) {
            mobileNumber = new MobileNumber(
                emv.ADDITIONAL_DATA_FIELD_MOBILE_NUMBER,
                mobileNumberInput
            );
            additionalDataString += mobileNumber.toString();
        }
        if (storeLabelInput != undefined) {
            storeLabel = new StoreLabel(emv.STORELABEL_TAG, storeLabelInput);
            additionalDataString += storeLabel.toString();
        }
        if (terminalLabelInput != undefined) {
            terminalLabel = new TerminalLabel(
                emv.TERMINAL_TAG,
                terminalLabelInput
            );
            additionalDataString += terminalLabel.toString();
        }

        if (purposeOfTransaction != undefined) {
            const purpose = new PurposeOfTransaction(emv.PURPOSE_OF_TRANSACTION, purposeOfTransaction)
            additionalDataString += purpose.toString()
        }

        super(tag, additionalDataString);

        // class inherit the billNumber, storeLabel, terminalLabel
        this.billNumber = billNumber;
        this.mobileNumber = mobileNumber;
        this.storeLabel = storeLabel;
        this.terminalLabel = terminalLabel;
        this.data = {
            billNumber: billNumber,
            mobileNumber: mobileNumber,
            storeLabel: storeLabel,
            terminalLabel: terminalLabel,
            purposeOfTransaction: purposeOfTransaction
        };
    }
}

class BillNumber extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.BILL_NUMBER || value == "")
            throw KHQRResponse(null, errorCode.BILL_NUMBER_LENGTH_INVALID);
        super(tag, value);
    }
}

class StoreLabel extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.STORE_LABEL || value == "")
            throw KHQRResponse(null, errorCode.STORE_LABEL_LENGTH_INVALID);
        super(tag, value);
    }
}

class TerminalLabel extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.TERMINAL_LABEL || value == "")
            throw KHQRResponse(null, errorCode.TERMINAL_LABEL_LENGTH_INVALID);
        super(tag, value);
    }
}

class MobileNumber extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.MOBILE_NUMBER || value == "")
            throw KHQRResponse(null, errorCode.MOBILE_NUMBER_LENGTH_INVALID);
        super(tag, value);
    }
}

class PurposeOfTransaction extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.PURPOSE_OF_TRANSACTION || value == "")
            throw KHQRResponse(null, errorCode.PURPOSE_OF_TRANSACTION_LENGTH_INVALID);
        super(tag, value);
    }
}

module.exports = AdditionalData;
