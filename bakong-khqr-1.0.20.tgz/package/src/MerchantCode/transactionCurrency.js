const { emv, errorCode, khqrData } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class TransactionCurrency extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined)
            throw KHQRResponse(null, errorCode.CURRENCY_TYPE_REQUIRED);
        else if (value.length > 3)
            throw KHQRResponse(null, errorCode.TRANSACTION_CURRENCY_LENGTH_INVALID);
        else if (![khqrData.currency.khr, khqrData.currency.usd].includes(parseInt(value)))
            throw KHQRResponse(null, errorCode.UNSUPPORTED_CURRENCY)
        super(tag, value);
    }
}

module.exports = TransactionCurrency
