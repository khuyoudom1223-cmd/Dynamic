const { errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class CRC extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined)
            throw KHQRResponse(null, errorCode.CRC_TAG_REQUIRED)
        else if (value.length > 4)
            throw KHQRResponse(null, errorCode.CRC_LENGTH_INVALID)
            
        super(tag, value)
    }
}

module.exports = CRC
