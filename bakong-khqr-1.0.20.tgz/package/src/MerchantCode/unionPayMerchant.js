const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class UnionpayMerchantAccount extends TagLengthString {
    constructor(tag, value) {
        if (value.length > emv.INVALID_LENGTH.UPI_MERCHANT)
            throw KHQRResponse(null, errorCode.UPI_ACCOUNT_INFORMATION_LENGTH_INVALID);
        super(tag, value)
    }
}

module.exports = UnionpayMerchantAccount