const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class PayloadFormatIndicator extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined)
            throw KHQRResponse(null, errorCode.PAYLOAD_FORMAT_INDICATOR_TAG_REQUIRED);
        else if (value.length > 2)
            throw KHQRResponse(null, errorCode.PAYLOAD_FORMAT_INDICATOR_LENGTH_INVALID);
        super(tag, value)
    }
}

module.exports = PayloadFormatIndicator