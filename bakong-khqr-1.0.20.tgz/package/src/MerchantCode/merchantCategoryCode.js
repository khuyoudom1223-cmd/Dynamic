const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class MerchantCategoryCode extends TagLengthString {
    constructor(tag, value) {
        if (value == ""  || value ==  null || value == undefined)
            throw KHQRResponse(null, errorCode.MERCHANT_CATEGORY_TAG_REQUIRED)
        else if (value.length > emv.INVALID_LENGTH.MERCHANT_CATEGORY_CODE)
            throw KHQRResponse(null, errorCode.MERCHANT_CODE_LENGTH_INVALID)
        else if (!/^\d+$/.test(value)) {
            throw KHQRResponse(null, errorCode.INVALID_MERCHANT_CATEGORY_CODE);
        } else {
            const mcc = parseInt(value, 10);
            if (mcc < 0 || mcc > 9999) {
                throw KHQRResponse(null, errorCode.INVALID_MERCHANT_CATEGORY_CODE);
            }
        }
        super(tag, value);
    }
}

module.exports = MerchantCategoryCode;
