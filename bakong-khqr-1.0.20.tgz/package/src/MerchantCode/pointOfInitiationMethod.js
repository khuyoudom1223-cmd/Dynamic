const { emv, errorCode } = require("../constant");
const { KHQRResponse } = require("../model");
const TagLengthString = require("../tagLengthString");

class PointOfInitiationMethod extends TagLengthString {
    constructor(tag, value) {
        if (value.length > 2) {
            throw KHQRResponse(null, errorCode.POINT_INITIATION_LENGTH_INVALID);
        }
        if(value !== emv.STATIC_QR && value !== emv.DYNAMIC_QR) {
            throw KHQRResponse(null, errorCode.POINT_OF_INITIATION_METHOD_INVALID);
        }
        super(tag, value)
    }
}

module.exports = PointOfInitiationMethod
