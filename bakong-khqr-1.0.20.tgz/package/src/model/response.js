const md5 = require("md5");

class KHQRData {
    constructor(qr) {
        this.qr = qr;
        this.md5 = md5(qr);
    }

    getData() {
        return {
            qr: this.qr,
            md5: this.md5,
        };
    }
}

class KHQRDeepLinkData {
    constructor(shortLink) {
        this.shortLink = shortLink;
    }

    getData() {
        return {
            shortLink: this.shortLink,
        };
    }
}

/**
 * A function for returning the KHQR response
 * the response has format
 * { status: { code: 0, errorCode: 0, message: '' },
 *   data: null }
 * How to use:
 * when error pass KHQRResponse(null, errorObject)
 * when success pass KHQRResponse(data, null)
 * @param {any} data
 * @param {any} errorObject
 * @returns
 */
function KHQRResponse(data, errorObject) {
    const isError = errorObject == null;
    const status = {
        code: !isError ? 1 : 0,
        errorCode: isError ? null : errorObject.code,
        message: isError ? null : errorObject.message,
    };
    return {
        status: status,
        data: data,
    };
}

module.exports = { KHQRData, KHQRDeepLinkData, KHQRResponse };
