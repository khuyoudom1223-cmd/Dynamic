const { khqrData } = require("../constant");

const removeEmptyElement = (obj) => {
    return Object.fromEntries(
        Object.entries(obj)
            .filter(([_, v]) => v != null)
            .filter(([_, v]) => v != undefined)
            .filter(([_, v]) => v != "")
    );
};

class IndividualInfo {
    /**
     * Individual information
     * fill the params down below
     * @param {*} bakongAccountID
     * @param {*} merchantName
     * @param {*} merchantCity
     * @param {*} optional
     */
    constructor(bakongAccountID, merchantName, merchantCity, optional = {}) {
        optional = removeEmptyElement(optional);
        if (
            this.isObject(bakongAccountID) ||
            this.isObject(merchantName) ||
            this.isObject(merchantCity)
        ) {
            throw "bakongAccountID, merchantName or merchantCity must be a string";
        }
        this.bakongAccountID = bakongAccountID;
        this.accountInformation = optional.accountInformation;
        this.acquiringBank = optional.acquiringBank;
        this.currency =
            optional.currency == undefined
                ? khqrData.currency.khr
                : optional.currency;
        this.amount = optional.amount;
        this.merchantName = merchantName;
        this.merchantCity = merchantCity;
        this.billNumber = optional.billNumber;
        this.storeLabel = optional.storeLabel;
        this.terminalLabel = optional.terminalLabel;
        this.mobileNumber = optional.mobileNumber;
        this.purposeOfTransaction = optional.purposeOfTransaction;
        this.languagePreference = optional.languagePreference;
        this.merchantNameAlternateLanguage = optional.merchantNameAlternateLanguage;
        this.merchantCityAlternateLanguage = optional.merchantCityAlternateLanguage;
        this.upiMerchantAccount = optional.upiMerchantAccount;
        this.expirationTimestamp = optional.expirationTimestamp;
        this.merchantCategoryCode = optional.merchantCategoryCode; // never empty('') due to removeEmptyElement, most likely <undefined>
    }

    isObject(val) {
        return val instanceof Object;
    }
}

class MerchantInfo extends IndividualInfo {
    /**
     * Merchant information
     * Fill the params down below
     * @param {*} bakongAccountID
     * @param {*} merchantName
     * @param {*} merchantCity
     * @param {*} merchantID
     * @param {*} acquiringBank
     * @param {*} optional
     */
    constructor(
        bakongAccountID,
        merchantName,
        merchantCity,
        merchantID,
        acquiringBank,
        optional = {}
    ) {
        optional = removeEmptyElement(optional);
        super(bakongAccountID, merchantName, merchantCity, optional);
        if (
            this.isObject(merchantID) ||
            this.isObject(acquiringBank)
        ) {
            throw "merchantID and acquiringBank must be a string";
        }
        this.amount = optional.amount;
        this.merchantID = merchantID;
        this.acquiringBank = acquiringBank;
    }
    isObject(val) {
        return val instanceof Object;
    }
}

module.exports = { IndividualInfo, MerchantInfo };
