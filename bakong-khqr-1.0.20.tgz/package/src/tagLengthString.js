class TagLengthString {
    constructor(tag, value) {
        this.tag = tag
        this.value = value

        const length =  String(value).length;
        this.length = length < 10 ? `0${length}` : String(length);
    }

    toString() {
        return `${this.tag}${this.length}${this.value}`
    }
}

module.exports = TagLengthString
