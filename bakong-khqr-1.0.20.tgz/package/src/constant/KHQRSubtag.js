const { emv } = require(".");

module.exports = {
    input: [
        {
            tag: "29",
            data: {
                bakongAccountID: null,
                accountInformation: null,
            },
        },
        {
            tag: "30",
            data: {
                bakongAccountID: null,
                merchantID: null,
                acquiringBank: null,
            },
        },
        {
            tag: "62",
            data: {
                billNumber: null,
                mobileNumber: null,
                storeLabel: null,
                terminalLabel: null,
                purposeOfTransaction: null
            },
        },
        {
            tag: "64",
            data: {
                languagePreference: null,
                merchantNameAlternateLanguage: null,
                merchantCityAlternateLanguage: null
            },
        },
        {
            tag: "99",
            data: {
                creationTimestamp: null,
                expirationTimestamp: null,
            },
        },
    ],
    compare: [
        {
            tag: "29",
            subTag: emv.BAKONG_ACCOUNT_IDENTIFIER,
            name: "bakongAccountID",
        },
        {
            tag: "29",
            subTag: emv.MERCHANT_ACCOUNT_INFORMATION_MERCHANT_ID,
            name: "accountInformation",
        },
        {
            tag: "29",
            subTag: emv.MERCHANT_ACCOUNT_INFORMATION_ACQUIRING_BANK,
            name: "acquiringBank",
        },
        {
            tag: "62",
            subTag: emv.BILLNUMBER_TAG,
            name: "billNumber",
        },
        {
            tag: "62",
            subTag: emv.ADDITIONAL_DATA_FIELD_MOBILE_NUMBER,
            name: "mobileNumber",
        },
        {
            tag: "62",
            subTag: emv.STORELABEL_TAG,
            name: "storeLabel",
        },
        {
            tag: "62",
            subTag: emv.PURPOSE_OF_TRANSACTION,
            name: "purposeOfTransaction",
        },
        {
            tag: "62",
            subTag: emv.TERMINAL_TAG,
            name: "terminalLabel",
        },
        {
            tag: "64",
            subTag: emv.LANGUAGE_PREFERENCE,
            name: "languagePreference",
        },
        {
            tag: "64",
            subTag: emv.MERCHANT_NAME_ALTERNATE_LANGUAGE,
            name: "merchantNameAlternateLanguage",
        },
        {
            tag: "64",
            subTag: emv.MERCHANT_CITY_ALTERNATE_LANGUAGE,
            name: "merchantCityAlternateLanguage",
        },
        {
            tag: "99",
            subTag: emv.CREATION_TIMESTAMP,
            name: "creationTimestamp",
        },
        {
            tag: "99",
            subTag: emv.EXPIRATION_TIMESTAMP,
            name: "expirationTimestamp",
        },
    ],
};
