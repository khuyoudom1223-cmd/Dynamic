// Merchant class
const {
    PointOfInitiationMethod,
    PayloadFormatIndicator,
    TransactionCurrency,
    MerchantCategoryCode,
    CountryCode,
    MerchantCity,
    TransactionAmount,
    MerchantName,
    TimeStamp,
    AdditionalData,
    CRC,
    GlobalUnqiueIdentifier,
    MerchantInformationLanguageTemplate,
    UnionpayMerchantAccount
} = require("../MerchantCode");

module.exports = [
    {
        tag: "00",
        type: "payloadFormatIndicator",
        required: true,
        instance: PayloadFormatIndicator,
    },
    {
        tag: "01",
        type: "pointofInitiationMethod",
        required: false,
        instance: PointOfInitiationMethod,
    },
    {
        tag: "15",
        type: "unionPayMerchant",
        required: false,
        instance: UnionpayMerchantAccount,
    },
    {
        sub: true,
        tag: "29",
        type: "globalUnqiueIdentifier",
        required: true,
        instance: GlobalUnqiueIdentifier,
    },
    {
        tag: "52",
        type: "merchantCategoryCode",
        required: true,
        instance: MerchantCategoryCode,
    },
    {
        tag: "53",
        type: "transactionCurrency",
        required: true,
        instance: TransactionCurrency,
    },
    {
        tag: "54",
        type: "transactionAmount",
        required: false,
        instance: TransactionAmount,
    },
    {
        tag: "58",
        type: "countryCode",
        required: true,
        instance: CountryCode,
    },
    {
        tag: "59",
        type: "merchantName",
        required: true,
        instance: MerchantName,
    },
    {
        tag: "60",
        type: "merchantCity",
        required: true,
        instance: MerchantCity,
    },
    {
        tag: "62",
        sub: true,
        type: "additionalData",
        required: false,
        instance: AdditionalData,
    },
    {
        tag: "64",
        sub: true,
        type: "merchantInformationLanguageTemplate",
        required: false,
        instance: MerchantInformationLanguageTemplate,
    },
    {
        tag: "99",
        sub: true,
        type: "timestamp",
        required: false,
        instance: TimeStamp,
    },
    {
        tag: "63",
        type: "crc",
        required: true,
        instance: CRC,
    },
];
