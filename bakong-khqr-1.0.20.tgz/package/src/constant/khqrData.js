const KHQRData = {
    currency: {
        usd: 840,
        khr: 116,
    },
    merchantType: {
        merchant: "merchant",
        individual: "individual",
    },
};

module.exports = KHQRData;
