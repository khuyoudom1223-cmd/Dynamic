// Constant variable
const { khqrData, errorCode, emv } = require("./constant");

// Controller for decoding and encoding
const crc16 = require("./helper/crc16");
const CRCValidation = require("./CRCValidation");

// Controller for deeplink
const {
    isValidLink,
    callDeepLinkAPI,
    SourceInfo,
} = require("./helper/deeplink");

// Model
const { KHQRDeepLinkData, KHQRResponse } = require("./model");
const { IndividualInfo, MerchantInfo } = require("./model/information");
const generateKHQR = require("./controller/generateKHQR");
const decodeKHQRString = require("./controller/decodeKHQR");
const decodeNonKHQR = require("./controller/decodeNonKHQR")
const md5 = require("md5");
const decodeKHQRValidation = require("./controller/decodeValidation");

const isAccountIDExist = require("./helper/checkAccountID");

class BakongKHQR {
    /**
     * Generate Individual
     * Passing indivualInfo which is the instance of the IndividualInfo
     * Example: const indivualInfo = new IndividualInfo("devit@abaa",
        khqrData.currency.khr,
        "devit",
        "Battambang",
        optionalData)
     * @param {*} individualInfo 
     * @returns object of KHQR Response
     */
    generateIndividual(individualInfo) {
        const khqr = generateKHQR(
            individualInfo,
            khqrData.merchantType.individual
        );

        if (khqr.status != undefined) return khqr

        const result = {
            qr: khqr,
            md5: md5(khqr),
        };
        return KHQRResponse(result, null);
    }

    /**
     * Generate Individual
     * Passing indivualInfo which is the instance of the IndividualInfo
     * Example: const indivualInfo = new MerchantInfo("devit@abaa",
        khqrData.currency.usd,
        "devit",
        "Battambang",
        optionalData)
     * @param {*} individualInfo 
     * @returns String of KHQR
     */
    generateMerchant(merchantInfo) {
        const khqr = generateKHQR(merchantInfo, khqrData.merchantType.merchant);

        if (khqr.status != undefined) return khqr;

        const result = {
            qr: khqr,
            md5: md5(khqr),
        };
        return KHQRResponse(result, null);
    }

    /**
     * Decode function
     * It is a static function
     * so you can use it as const decodeResult = BakongKHQR.decode(KHQRString)
     * @param {String} KHQRString
     * @returns object of KHQR Response
     */
    static decode(KHQRString) {
        const decodedData = decodeKHQRString(KHQRString);

        return KHQRResponse(decodedData, null);
        // try {
        //     const isValidKHQR = this.verify(KHQRString).isValid;
        //     if (!isValidKHQR || KHQRString.length < emv.INVALID_LENGTH.KHQR)
        //         throw KHQRResponse(null, errorCode.KHQR_INVALID);

        //     const decodedData = decodeKHQRString(KHQRString);

        //     return KHQRResponse(decodedData, null);
        // } catch (error) {
        //     return error;
        // }
    }

    /**
     * Decode a non-KHQR string
     * 
     * @param {*} KHQRString - The QR code string to decode.
     * @returns {Object} The decoded object.
     */
    static decodeNonKhqr(KHQRString) {
        return KHQRResponse(decodeNonKHQR(KHQRString), null);
    }

    /**
     * Verify KHQR
     * This function is a static function
     * it can be used as const isVerifiedKHQR = BakongKHQR.verify(KHQRString)
     * @param {String} KHQRString 
     * @returns Verification object
     */
    static verify(KHQRString) {
        const isCorrectFormCRC = checkCRCRegExp(KHQRString);
        if (!isCorrectFormCRC) return new CRCValidation(false)

        const crc = KHQRString.slice(-4);
        const KHQRNoCrc = KHQRString.slice(0, -4);
        const validCRC = crc16(KHQRNoCrc) == crc.toUpperCase();
        const isValidCRC = new CRCValidation(validCRC);
        try {
            if (!isValidCRC.isValid || KHQRString.length < emv.INVALID_LENGTH.KHQR)
                throw KHQRResponse(null, errorCode.KHQR_INVALID);

            decodeKHQRValidation(KHQRString);

            return new CRCValidation(true);
        } catch (error) {
            return new CRCValidation(false);
        }
    }

    /**
     * Generate Deep Link
     * @param {String} url 
     * @param {String} qr 
     * @param {SourceInfo} sourceInfo (optional)
     * @returns 
     */
    static async generateDeepLink(url, qr, sourceInfo) {
        // check invalid url
        const validURL = isValidLink(url);
        if (!validURL)
            return KHQRResponse(null, errorCode.INVALID_DEEP_LINK_URL);

        // check qr is valid (CRC)
        const isValidKHQR = this.verify(qr);

        if (!isValidKHQR.isValid)
            return KHQRResponse(null, errorCode.KHQR_INVALID);

        // check data source field
        if (sourceInfo) {
            if (
                !sourceInfo.appIconUrl ||
                !sourceInfo.appName ||
                !sourceInfo.appDeepLinkCallback
            )
                return KHQRResponse(
                    null,
                    errorCode.INVALID_DEEP_LINK_SOURCE_INFO
                );
        }

        // call API to generate deeplink
        try {
            const data = await callDeepLinkAPI(url, { qr: qr });

            const deepLinkData = new KHQRDeepLinkData(data.data.shortLink);

            return KHQRResponse(deepLinkData.getData(), null);
        } catch (error) {
            return error;
        }
    }

    /**
     * Check Bakong Account wether it is exist or not
     * @param {*} url 
     * @param {*} bakongID 
     * @returns 
     */
    static async checkBakongAccount(url, bakongID) {
        try {
            const accountExistResponse = await isAccountIDExist(url, bakongID)
            return KHQRResponse(accountExistResponse, null);
        } catch (error) {
            return error
        }
    }
}

function checkCRCRegExp(crc) {
    const crcRegExp = /6304[A-Fa-f0-9]{4}$/
    return crcRegExp.test(crc)
}

module.exports = {
    BakongKHQR,
    khqrData,
    SourceInfo,
    IndividualInfo,
    MerchantInfo,
};
