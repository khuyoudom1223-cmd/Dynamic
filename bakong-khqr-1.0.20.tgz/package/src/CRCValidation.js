class CRCValidation {
    constructor(valid) {
        this.isValid = valid
    }
}

module.exports = CRCValidation
