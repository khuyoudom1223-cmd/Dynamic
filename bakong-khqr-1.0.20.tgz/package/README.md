# KHQR (Khmer QRCode)
KHQR is the centralized QRCode for Cambodia, where every mobile banking app in Cambodia can scan and pay.
KHQR ~ Scan.Pay.Done.

# Changelog
- decode caching

# Installation

## Run unit test
```
npm run test
```

## NPM
```
npm install bakong-khqr
```

## Raw Script
Link the script src to html
```
<script src="https://github.com/davidhuotkeo/bakong-khqr/releases/download/bakong-khqr-1.0.6/khqr-1.0.6.min.js"></script>
```

# Usage

## NPM
```
const {BakongKHQR, khqrData, IndividualInfo, MerchantInfo, SourceInfo} = require("bakong-khqr");
```

or

```
import {BakongKHQR, khqrData, IndividualInfo, MerchantInfo, SourceInfo} from "bakong-khqr";
```

## Raw Script
In your script file/tag
```
var {BakongKHQR, khqrData, IndividualInfo, MerchantInfo, SourceInfo} = BakongKHQR;
```


# How to use KHQR Javascript Library?

## Generate KHQRCode
There are 2 way of generating KHQR: Individual and Merchant

### Merchant KHQR
```javascript
const {BakongKHQR, khqrData} = require("bakong-khqr");
const optionalData = {
    currency: khqrData.currency.khr,
    amount: 100000,
    billNumber: "#0001",
    mobileNumber: "85587575857",
    storeLabel: "Devit Huotkeo",
    terminalLabel: "Devit I",
    expirationTimestamp: Date.now() + (1 * 60 * 1000), // required if amount is not null or zero (eg. expired in 1 minutes)
    merchantCategoryCode: "5999", // optional: default value 5999
};

const merchantInfo = new MerchantInfo(
    "devit@abaa",
    "devit",
    "Battambang",
    1243546472,
    "DEVBKKHPXXX",
    optionalData
);

const khqr = new BakongKHQR();
const response = khqr.generateMerchant(merchantInfo);

console.log(response);
```

### Individual KHQR
```javascript
const {BakongKHQR, khqrData} = require("bakong-khqr");
const optionalData = {
    currency: khqrData.currency.khr,
    amount: 100000,
    billNumber: "#0001",
    mobileNumber: "85587575857",
    storeLabel: "Devit Huotkeo",
    terminalLabel: "Devit I",
    expirationTimestamp: Date.now() + (2 * 60 * 1000), // required if dynamic KHQR (eg. expired in 2 minutes)
    merchantCategoryCode: "5999", // optional: default value 5999
};

const individualInfo = new IndividualInfo(
    "devit@abaa",
    khqrData.currency.khr,
    "devit",
    "Battambang",
    optionalData
);

const khqr = new BakongKHQR();
const response = khqr.generateIndividual(individualInfo);

console.log(response);
```

## Verify KHQR
```javascript
const {BakongKHQR} = require("bakong-khqr");

const KHQRString =
    "00020101021230190015john_smith@devb5204599953038405405500.05802KH5910John Smith6010Phnom Penh62640111Invoice#0690314Coffee Khlaing0727Cooooooooooooooooooounter 299340013172734056490701131727340624907630458D8";
const isKHQR = BakongKHQR.verify(KHQRString).isValid;

console.log(isKHQR);
```

## Decode
```javascript
const {BakongKHQR, khqrData} = require("bakong-khqr");

const KHQRString =
    "00020101021230190015john_smith@devb5204599953038405405500.05802KH5910John Smith6010Phnom Penh62640111Invoice#0690314Coffee Khlaing0727Cooooooooooooooooooounter 299340013172734056490701131727340624907630458D8";
const decodeResult = BakongKHQR.decode(KHQRString);
console.log(decodeResult);
```

## Decode Non-KHQR
```javascript
const {BakongKHQR} = require("bakong-khqr");

const KHQRString =
    "00020101021230190015john_smith@devb5204599953038405405500.05802KH5910John Smith6010Phnom Penh62640111Invoice#0690314Coffee Khlaing0727Cooooooooooooooooooounter 299340013172734056490701131727340624907630458D8";
const decodeResult = BakongKHQR.decodeNonKhqr(KHQRString);
console.log(decodeResult);
```

## Deeplink
```javascript
const {BakongKHQR, khqrData, SourceInfo} = require("bakong-khqr");

const khqr = new BakongKHQR();

// Source Info is optional but if you include it
// all fields appIconUrl, appName, appDeepLinkCallback must not be null
const sourceInfo = new SourceInfo(yourAppIconUrl, yourAppName, yourAppDeepLinkCallback);
const url = "generate deep link url provided by us";
const KHQRString =
    "00020101021230190015john_smith@devb5204599953038405405500.05802KH5910John Smith6010Phnom Penh62640111Invoice#0690314Coffee Khlaing0727Cooooooooooooooooooounter 299340013172734056490701131727340624907630458D8";

const deepLinkURL = khqr.generateDeepLink(url, KHQRString, sourceInfo);

deepLinkURL.then(url => console.log(url))
```

## Check bakong account ID
```javascript
const {BakongKHQR} = require("bakong-khqr");

BakongKHQR.checkBakongAccount(
    "open API URL",
    "dave@devb"
).then((data) => console.log(data));
```
