const { BakongKHQR, IndividualInfo, khqrData } = require("../src");

const expirationTimestamp = Date.now() + (1 * 60 * 1000)

const testData = [
    {
        statement: "Success Generate 1",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "PHNOM PENH",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 1,
                billNumber: "INV-2021-07-65822",
                expirationTimestamp,
            },
        },
        result: "00020101021229180014jonhsmith@nbcq520459995303840540115802KH5910Jonh Smith6010PHNOM PENH62210117INV-2021-07-65822",
    },
    {
        statement: "Success Generate 2",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Phnom Penh",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 50000,
                mobileNumber: "85512345678",
                expirationTimestamp,
            },
        },
        result: "00020101021229180014jonhsmith@nbcq5204599953031165405500005802KH5910Jonh Smith6010Phnom Penh6215021185512345678",
    },
    {
        statement: "Success Generate 3",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Phnom Penh",
            },
            optional: {
                amount: 50000,
                storeLabel: "BKK-1",
                expirationTimestamp,
            },
        },
        result: "00020101021229180014jonhsmith@nbcq5204599953031165405500005802KH5910Jonh Smith6010Phnom Penh62090305BKK-1",
    },
    {
        statement: "Success Generate 4",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 50000,
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                expirationTimestamp,
            },
        },
        result: "00020101021229180014jonhsmith@nbcq5204599953031165405500005802KH5910Jonh Smith6009Siam Reap62550117INV-2021-07-658220211855123456780305BKK-10706012345",
    },
    {
        statement: "Success Generate 5",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 50000,
                acquiringBank: "Dev Bank",
                accountInformation: "012345678",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                expirationTimestamp,
            },
        },
        result: "00020101021229430014jonhsmith@nbcq01090123456780208Dev Bank5204599953031165405500005802KH5910Jonh Smith6009Siam Reap62550117INV-2021-07-658220211855123456780305BKK-10706012345",
    },
    {
        statement: "Success Generate 6",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 50000,
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                acquiringBank: "Dev Bank",
                expirationTimestamp,
            },
        },
        result: "00020101021229300014jonhsmith@nbcq0208Dev Bank5204599953031165405500005802KH5910Jonh Smith6009Siam Reap62550117INV-2021-07-658220211855123456780305BKK-10706012345",
    },
    {
        statement: "Success Generate 7",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 50000,
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                acquiringBank: "Dev Bank",
                expirationTimestamp,
            },
        },
        result: "00020101021229300014jonhsmith@nbcq0208Dev Bank5204599953031165405500005802KH5910Jonh Smith6009Siam Reap62550117INV-2021-07-658220211855123456780305BKK-10706012345",
    },
    {
        statement: "Success Generate 8",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 50000,
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "00020101021229310014jonhsmith@nbcq01090123456785204599953031165405500005802KH5910Jonh Smith6009Siam Reap62550117INV-2021-07-658220211855123456780305BKK-10706012345",
    },
    {
        statement: "Success Generate 9",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                languagePreference: "km",
                merchantNameAlternateLanguage: "ចន ស្មីន",
                merchantCityAlternateLanguage: "សៀមរាប",
            },
        },
        result: "00020101021129180014jonhsmith@nbcq5204599953031165802KH5910Jonh Smith6009Siam Reap64280002km0108ចន ស្មីន0206សៀមរាប",
    },
    {
        statement: "Success Generate 10",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Phnom Penh",
            },
            optional: {
                mobileNumber: "85512345678",
                purposeOfTransaction: "Testing"
            },
        },
        result: "00020101021129180014jonhsmith@nbcq5204599953031165802KH5910Jonh Smith6010Phnom Penh62260211855123456780807Testing",
    },
];

testData.forEach((data) => {
    test(data.statement, () => {
        const requiredData = data.data.require;
        const optionalData = data.data.optional;
        const sliceIndex = optionalData.amount !== undefined ? -46 : -8

        const individualData = new IndividualInfo(
            requiredData.bakongAccountID,
            requiredData.merchantName,
            requiredData.merchantCity,
            optionalData
        );

        const khqr = new BakongKHQR();
        const result = khqr.generateIndividual(individualData);
        expect(result.data.qr.slice(0, sliceIndex)).toBe(data.result);
    });
});

amountTestData = [
    {
        statement: "Amount test 1",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 100.0,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "100",
    },
    {
        statement: "Amount test 2",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 100.0,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "100",
    },
    {
        statement: "Amount test 3",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 100.0,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "100",
    },
    {
        statement: "Amount test 4",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 9999999999.0,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "9999999999",
    },
    {
        statement: "Amount test 5",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 10000,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "10000",
    },
    {
        statement: "Amount test 6",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 1.12,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "1.12",
    },
    {
        statement: "Amount test 7",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 1000,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "1000",
    },
    {
        statement: "Amount test 8",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 100.11,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "100.11",
    },
    {
        statement: "Amount test 9",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 100.12,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "100.12",
    },
    {
        statement: "Amount test 10",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 12345678901.0,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "12345678901",
    },
    {
        statement: "Amount test 11",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "Jonh Smith",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 9999999999.99,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "9999999999.99",
    },
    {
        statement: "Name in UTF-8",
        data: {
            require: {
                bakongAccountID: "jonhsmith@nbcq",
                merchantName: "ចន ស្មីន",
                merchantCity: "Siam Reap",
            },
            optional: {
                currency: khqrData.currency.khr,
                amount: 100.0,
                acquiringBank: "Dev Bank",
                mobileNumber: "85512345678",
                billNumber: "INV-2021-07-65822",
                storeLabel: "BKK-1",
                terminalLabel: "012345",
                accountInformation: "012345678",
                expirationTimestamp,
            },
        },
        result: "100",
    },
];

amountTestData.forEach((data) => {
    test(data.statement, () => {
        const requiredData = data.data.require;
        const optionalData = data.data.optional;

        const individualData = new IndividualInfo(
            requiredData.bakongAccountID,
            requiredData.merchantName,
            requiredData.merchantCity,
            optionalData
        );

        const khqr = new BakongKHQR();

        const result = khqr.generateIndividual(individualData);
        const decodeValue = BakongKHQR.decode(result.data.qr);

        expect(decodeValue.data.transactionAmount).toBe(data.result);
    });
});
