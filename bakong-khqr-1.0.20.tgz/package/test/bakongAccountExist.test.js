const { BakongKHQR } = require("../src");
const { errorCode } = require("../src/constant");

const testData = [
    {
        statement: "Account exists",
        data: {
            url: "https://sit-api-bakong.nbc.gov.kh/v1/check_account_exist",
            account: "dave@devb",
        },
        errorCode: null,
    },
    {
        statement: "Account not found",
        data: {
            url: "https://sit-api-bakong.nbc.gov.kh/v1/check_account_exist",
            account: "dope@devb",
        },
        errorCode: null,
    },
    {
        statement: "Invalid account length",
        data: {
            url: "https://sit-api-bakong.nbc.gov.kh/v1/check_account_exist",
            account: "dopedopedopedopedopedopedope@devb",
        },
        errorCode: errorCode.BAKONG_ACCOUNT_ID_LENGTH_INVALID.code,
    },
    {
        statement: "Account is invalid",
        data: {
            url: "https://sit-api-bakong.nbc.gov.kh/v1/check_account_exist",
            account: "davedevb",
        },
        errorCode: errorCode.BAKONG_ACCOUNT_ID_INVALID.code,
    },
    {
        statement: "Invalid URL",
        data: {
            url: "https://sit-sit-api-bakong.nbc.gov.kh/v1/check_account_exist",
            account: "dave@devb",
        },
        errorCode: errorCode.CONNECTION_TIMEOUT.code,
    },
];

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

testData.forEach((data) => {
    test(data.statement, async () => {
        const checkAcc = await BakongKHQR.checkBakongAccount(data.data.url, data.data.account)

        expect(checkAcc.status.errorCode).toBe(data.errorCode)
    });
});
