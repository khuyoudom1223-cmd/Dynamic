const { BakongKHQR, SourceInfo } = require("../src");
const { TimeStamp } = require("../src/MerchantCode");
const { emv } = require("../src/constant");
const crc16 = require("../src/helper/crc16");

const testData = [
    {
        statement: "Invalid DeepLink URL",
        data: [
            "https://sit-api-bakong.nbc.gov.kh/deeplink",
            "00020101021229190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
        ],
        errorCode: 29,
    },
    {
        statement: "Null callback source info",
        data: [
            "https://sit-api-bakong.nbc.gov.kh/v1/generate_deeplink_by_qr",
            "00020101021229190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
            new SourceInfo(
                "https://sit-api-bakong.nbc.gov.kh/khqr.png",
                "KHQR",
                null
            ),
        ],
        errorCode: 14,
    },
    {
        statement: "Null icon source info",
        data: [
            "https://sit-api-bakong.nbc.gov.kh/v1/generate_deeplink_by_qr",
            "00020101021229190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
            new SourceInfo(
                null,
                "KHQR",
                "https://sit-api-bakong.nbc.gov.kh/callback"
            ),
        ],
        errorCode: 14,
    },
    {
        statement: "Null name source info",
        data: [
            "https://sit-api-bakong.nbc.gov.kh/v1/generate_deeplink_by_qr",
            "00020101021229190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
            new SourceInfo(
                "https://sit-api-bakong.nbc.gov.kh/khqr.png",
                null,
                "https://sit-api-bakong.nbc.gov.kh/callback"
            ),
        ],
        errorCode: 14,
    },
    {
        statement: "Invalid QR",
        data: [
            "https://sit-api-bakong.nbc.gov.kh/v1/generate_deeplink_by_qr",
            "00020101021029190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
        ],
        errorCode: 8,
    },
    {
        statement: "Deeplink timeout",
        data: [
            "https://fake-deeplink-api.herokuapp.com/v1/generate_deeplink_by_qr",
            "00020101021229190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
        ],
        errorCode: 13,
    },
    {
        statement: "Generating DeepLink successfully",
        data: [
            "https://sit-api-bakong.nbc.gov.kh/v1/generate_deeplink_by_qr",
            "00020101021229190015john_smith@devb5204599953038405405100.05802KH5910John Smith6010Phnom Penh",
        ],
        errorCode: null,
    },
];

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

const timestamp = new TimeStamp(emv.TIMESTAMP_TAG, {
    creationTimestamp: Date.now(),
    expirationTimestamp: Date.now() + 60 * 1000,
}, emv.DYNAMIC_QR);
testData.forEach((data) => {
    test(data.statement, async () => {
        let khqr = data.data[1] + timestamp.toString() + emv.CRC + emv.CRC_LENGTH;
        khqr += crc16(khqr)
        const decodeResponse = await BakongKHQR.generateDeepLink(
            data.data[0],
            khqr,//data.data[1],
            data.data[2]
        );

        expect(decodeResponse.status.errorCode).toBe(data.errorCode);
    }, 45 * 1000);
});
