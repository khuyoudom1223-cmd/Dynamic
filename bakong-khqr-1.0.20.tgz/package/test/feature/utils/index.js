const { BakongKHQR, IndividualInfo, MerchantInfo } = require("../../../src");

/**
 * Generate KHQR Test Suite
 * 
 * @param {Array<Object>} testItems 
 * @param {boolean} isMerchant 
 * @param {boolean} isNegative 
 */
function runKhqrGenerateTests(testItems, isMerchant = false, isNegative = false) {
    testItems.forEach((data) => {
        test(data.statement, () => {
            const requiredData = data.data.require;
            const optionalData = data.data.optional;

            let result;
            const khqr = new BakongKHQR();
            if (isMerchant) {
                const merchantData = new MerchantInfo(
                    requiredData.bakongAccountID,
                    requiredData.merchantName,
                    requiredData.merchantCity,
                    requiredData.merchantId,
                    requiredData.acquiringBank,
                    optionalData
                );
                result = khqr.generateMerchant(merchantData);
            } else {
                const individualData = new IndividualInfo(
                    requiredData.bakongAccountID,
                    requiredData.merchantName,
                    requiredData.merchantCity,
                    optionalData,
                );
                result = khqr.generateIndividual(individualData);
            }

            if (isNegative) {
                expect(result.status.errorCode).toBe(data.result.error.code);
            } else {
                const sliceIndex = optionalData.amount !== undefined ? -46 : -8;
                expect(result.data.qr.slice(0, sliceIndex)).toBe(data.result);
            }
        });
    });
}

module.exports = {
    runKhqrGenerateTests
};