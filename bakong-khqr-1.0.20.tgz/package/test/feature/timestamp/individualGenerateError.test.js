const { khqrData } = require("../../../src");
const { errorCode } = require("../../../src/constant");
const { runKhqrGenerateTests } = require("../utils");

const testData = [
    {
        statement: "Expiration timestamp is required for dynamic KHQR",
        data: {
            require: {
                bakongAccountID: "johnsmith@devb",
                merchantName: "Jonh Smith",
                merchantCity: "PHNOM PENH",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 101.3,
            },
        },
        result: {
            error: errorCode.EXPIRATION_TIMESTAMP_REQUIRED,
        },
    },
    {
        statement: "Expiration timestamp is in the past",
        data: {
            require: {
                bakongAccountID: "johnsmith@devb",
                merchantName: "Jonh Smith",
                merchantCity: "PHNOM PENH",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 101.3,
                expirationTimestamp: 1727260807000
            },
        },
        result: {
            error: errorCode.EXPIRATION_TIMESTAMP_IN_THE_PAST,
        },
    },
    {
        statement: "Expiration timestamp length is invalid",
        data: {
            require: {
                bakongAccountID: "johnsmith@devb",
                merchantName: "Jonh Smith",
                merchantCity: "PHNOM PENH",
            },
            optional: {
                currency: khqrData.currency.usd,
                amount: 101.3,
                expirationTimestamp: 1727260807
            },
        },
        result: {
            error: errorCode.EXPIRATION_TIMESTAMP_LENGTH_INVALID,
        },
    },
];

runKhqrGenerateTests(testData, false, true);