const { errorCode } = require("../../../src/constant");
const { runKhqrGenerateTests } = require("../utils");

const accountInfo = {
    bakongAccountID: "jonhsmith@nbcq",
    merchantName: "Jonh Smith",
    merchantCity: "Phnom Penh",
    merchantId: "123456",
    acquiringBank: "Dev Bank",
}

const positiveCases = [
    {
        statement: "Feature MCC: Success Generate Merchant KHQR Test 1",
        data: {
            require: accountInfo,
            optional: {
                merchantCategoryCode: "0000",
            },
        },
        result: "00020101021130400014jonhsmith@nbcq01061234560208Dev Bank5204000053031165802KH5910Jonh Smith6010Phnom Penh",
    },
    {
        statement: "Feature MCC: Success Generate Merchant KHQR Test 2",
        data: {
            require: accountInfo,
            optional: {
                merchantCategoryCode: "1234",
            },
        },
        result: "00020101021130400014jonhsmith@nbcq01061234560208Dev Bank5204123453031165802KH5910Jonh Smith6010Phnom Penh",
    },
];

const negativeCases = [
    {
        statement: "Feature MCC: Failed Generate Merchant KHQR Test 1",
        data: {
            require: accountInfo,
            optional: {
                merchantCategoryCode: "1A2B",
            },
        },
        result: {
            error: errorCode.INVALID_MERCHANT_CATEGORY_CODE,
        },
    },
    {
        statement: "Feature MCC: Failed Generate Merchant KHQR Test 2",
        data: {
            require: accountInfo,
            optional: {
                merchantCategoryCode: "-100",
            },
        },
        result: {
            error: errorCode.INVALID_MERCHANT_CATEGORY_CODE,
        },
    },
];

runKhqrGenerateTests(positiveCases, true);
runKhqrGenerateTests(negativeCases, true, true);