var PACKAGE = require("./package.json");
var version = PACKAGE.version;

module.exports = {
    mode: "production",
    entry: "./src",
    output: {
        filename: `khqr-${version}.min.js`,
        library: "BakongKHQR",
        libraryTarget: "umd",
    },
};
